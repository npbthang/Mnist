import streamlit as st
from Buoi5.Clustering_Algorithms import main

st.title("🔢 Classification MNIST")


# Gọi hàm Classification từ modul
main()