import streamlit as st
from Buoi4.Classification import main

st.title("🔢 Classification MNIST")


# Gọi hàm Classification từ modul
main()
    