import streamlit as st
from Buoi3.Linear_Regression import main

st.title("📈 Linear Regression")


# Gọi hàm main từ module
main()