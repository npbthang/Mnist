import streamlit as st
from Buoi6.PCA_t_SNE import main

st.title("🔢 Assignment - PCA & t-SNE MNIST")


# Gọi hàm Classification từ modul
main()
    