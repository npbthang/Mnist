import streamlit as st
from Buoi7.NeuralNetwork import main

st.title("🔢 NeuralNetwork")


# Gọi hàm main từ module
main()