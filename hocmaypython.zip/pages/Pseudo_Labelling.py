import streamlit as st
from Buoi8.Semi_supervised import main

st.title("🔢 Pseudo Labelling MNIST")


# Gọi hàm Classification từ modul
main()
    